<?php
session_start();
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_SESSION['user_id'])) {
    $uniform_name = $_POST['uniform_name'];
    $user_id = $_SESSION['user_id'];
    $return_date = date("Y-m-d");

    $sql = "INSERT INTO returns (user_id, uniform_name, return_date) VALUES ('$user_id', '$uniform_name', '$return_date')";

    if ($conn->query($sql) === TRUE) {
        header("Location: dashboard.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
