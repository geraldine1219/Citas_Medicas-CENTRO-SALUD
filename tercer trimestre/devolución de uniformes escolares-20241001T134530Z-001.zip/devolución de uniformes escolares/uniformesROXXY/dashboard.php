<?php
session_start();
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit;
}

$user_id = $_SESSION['user_id'];

// Mostrar devoluciones
$sql = "SELECT * FROM returns WHERE user_id = '$user_id'";
$result = $conn->query($sql);

echo "<h2>Mis Devoluciones</h2>";
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<p>Uniforme: " . $row['uniform_name'] . " | Fecha: " . $row['return_date'] . " <a href='delete-return.php?id=" . $row['id'] . "'>Eliminar</a></p>";
    }
} else {
    echo "<p>No tienes devoluciones registradas.</p>";
}

// Formulario para agregar devolución
?>

<form action="add-return.php" method="POST">
    <label for="uniform_name">Uniforme:</label>
    <input type="text" id="uniform_name" name="uniform_name" required>
    <button type="submit">Agregar Devolución</button>
</form>

<?php
$conn->close();
?>
