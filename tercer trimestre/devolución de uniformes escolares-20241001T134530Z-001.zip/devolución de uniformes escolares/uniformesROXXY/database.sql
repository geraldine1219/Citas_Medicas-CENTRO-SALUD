CREATE DATABASE uniforms_db;

USE uniforms_db;

CREATE TABLE users (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    reset_token VARCHAR(100) DEFAULT NULL
);

CREATE TABLE returns (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    user_id INT(11) NOT NULL,
    uniform_name VARCHAR(100) NOT NULL,
    return_date DATE NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id)
);
