<?php
session_start();
include 'config.php';

if (isset($_GET['id']) && isset($_SESSION['user_id'])) {
    $return_id = $_GET['id'];
    $user_id = $_SESSION['user_id'];

    $sql = "DELETE FROM returns WHERE id='$return_id' AND user_id='$user_id'";

    if ($conn->query($sql) === TRUE) {
        header("Location: dashboard.php");
    } else {
        echo "Error al eliminar la devolución.";
    }

    $conn->close();
}
?>
