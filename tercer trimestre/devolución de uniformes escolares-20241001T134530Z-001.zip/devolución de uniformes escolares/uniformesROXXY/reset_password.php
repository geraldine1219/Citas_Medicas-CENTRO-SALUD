<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];

    $sql = "SELECT * FROM users WHERE email = '$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Generar un token de recuperación
        $token = bin2hex(random_bytes(50));
        $sql = "UPDATE users SET reset_token='$token' WHERE email='$email'";
        if ($conn->query($sql) === TRUE) {
            // Enviar email con el enlace de recuperación (omitido en este ejemplo)
            echo "Enlace de recuperación enviado a tu correo.";
        } else {
            echo "Error al generar el token.";
        }
    } else {
        echo "Correo no registrado.";
    }

    $conn->close();
}
?>
