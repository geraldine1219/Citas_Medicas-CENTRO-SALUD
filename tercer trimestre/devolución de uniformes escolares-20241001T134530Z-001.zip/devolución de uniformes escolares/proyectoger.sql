create database sistemaDevolucionUniformesEscolares;
USE sistemaDevolucionUniformesEscolares;

-- Tabla de Usuarios
CREATE TABLE usuarios (
    id_usuario INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(50),
    email VARCHAR(100) UNIQUE,
    contrasena VARCHAR(100),
    rol ENUM('usuario')
);

# Inserción de datos:

INSERT INTO usuarios (nombre, email, contrasena, rol)
VALUES
('Usuario 1', 'usuario1@ejemplo.com', SHA2('contrasena1', 256), 'usuario'),
('Usuario 2', 'usuario2@ejemplo.com', SHA2('contrasena2', 256), 'usuario'),
('Usuario 3', 'usuario3@ejemplo.com', SHA2('contrasena3', 256), 'usuario'),
('Usuario 4', 'usuario4@ejemplo.com', SHA2('contrasena4', 256), 'usuario'),
('Usuario 5', 'usuario5@ejemplo.com', SHA2('contrasena5', 256), 'usuario'),
('Usuario 6', 'usuario6@ejemplo.com', SHA2('contrasena6', 256), 'usuario'),
('Usuario 7', 'usuario7@ejemplo.com', SHA2('contrasena7', 256), 'usuario'),
('Usuario 8', 'usuario8@ejemplo.com', SHA2('contrasena8', 256), 'usuario'),
('Usuario 9', 'usuario9@ejemplo.com', SHA2('contrasena9', 256), 'usuario'),
('Usuario 10', 'usuario10@ejemplo.com', SHA2('contrasena10', 256), 'usuario'),
('Usuario 11', 'usuario11@ejemplo.com', SHA2('contrasena11', 256), 'usuario'),
('Usuario 12', 'usuario12@ejemplo.com', SHA2('contrasena12', 256), 'usuario'),
('Usuario 13', 'usuario13@ejemplo.com', SHA2('contrasena13', 256), 'usuario'),
('Usuario 14', 'usuario14@ejemplo.com', SHA2('contrasena14', 256), 'usuario'),
('Usuario 15', 'usuario15@ejemplo.com', SHA2('contrasena15', 256), 'usuario');

select * from usuarios;

-- tabla admnistrador
CREATE TABLE administrador (
    id_usuario INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(50),
    email VARCHAR(100) UNIQUE,
    contrasena VARCHAR(100),
    rol ENUM('administrador')
);

INSERT INTO administrador (nombre, email, contrasena, rol)
VALUES
('Admin 1', 'admin1@ejemplo.com', SHA2('contrasenaA1', 256), 'administrador'),
('Admin 2', 'admin2@ejemplo.com', SHA2('contrasenaA2', 256), 'administrador'),
('Admin 3', 'admin3@ejemplo.com', SHA2('contrasenaA3', 256), 'administrador'),
('Admin 4', 'admin4@ejemplo.com', SHA2('contrasenaA4', 256), 'administrador'),
('Admin 5', 'admin5@ejemplo.com', SHA2('contrasenaA5', 256), 'administrador'),
('Admin 6', 'admin6@ejemplo.com', SHA2('contrasenaA6', 256), 'administrador'),
('Admin 7', 'admin7@ejemplo.com', SHA2('contrasenaA7', 256), 'administrador'),
('Admin 8', 'admin8@ejemplo.com', SHA2('contrasenaA8', 256), 'administrador'),
('Admin 9', 'admin9@ejemplo.com', SHA2('contrasenaA9', 256), 'administrador'),
('Admin 10', 'admin10@ejemplo.com', SHA2('contrasenaA10', 256), 'administrador'),
('Admin 11', 'admin11@ejemplo.com', SHA2('contrasenaA11', 256), 'administrador'),
('Admin 12', 'admin12@ejemplo.com', SHA2('contrasenaA12', 256), 'administrador'),
('Admin 13', 'admin13@ejemplo.com', SHA2('contrasenaA13', 256), 'administrador'),
('Admin 14', 'admin14@ejemplo.com', SHA2('contrasenaA14', 256), 'administrador'),
('Admin 15', 'admin15@ejemplo.com', SHA2('contrasenaA15', 256), 'administrador');

select * from administrador;

---------------------------------------

CREATE TABLE sesiones (
    id_sesion INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT,  -- Llave foránea que referencia a la tabla de usuarios
    fecha_inicio DATETIME NOT NULL,  -- Momento en que inicia la sesión
    fecha_fin DATETIME,  -- Momento en que finaliza la sesión (puede ser NULL si está en curso)
    ip_v4 VARCHAR(45),  -- IP del usuario al iniciar la sesión
    navegador VARCHAR(100),  -- Información del navegador usado
    sistema_operativo VARCHAR(100),  -- Sistema operativo del usuario
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id) ON DELETE CASCADE
);

INSERT INTO sesiones (id_usuario, fecha_inicio, fecha_fin)
VALUES
(1, '2024-09-01 08:00:00', '2024-09-01 09:00:00'),
(2, '2024-09-01 08:30:00', '2024-09-01 09:30:00'),
(3, '2024-09-02 10:00:00', '2024-09-02 11:00:00'),
(4, '2024-09-02 11:30:00', '2024-09-02 12:30:00'),
(5, '2024-09-03 08:00:00', '2024-09-03 09:00:00'),
(6, '2024-09-03 08:30:00', '2024-09-03 09:30:00'),
(7, '2024-09-04 10:00:00', '2024-09-04 11:00:00'),
(8, '2024-09-04 11:30:00', '2024-09-04 12:30:00'),
(9, '2024-09-05 08:00:00', '2024-09-05 09:00:00'),
(10, '2024-09-05 08:30:00', '2024-09-05 09:30:00'),
(11, '2024-09-06 10:00:00', '2024-09-06 11:00:00'),
(12, '2024-09-06 11:30:00', '2024-09-06 12:30:00'),
(13, '2024-09-07 08:00:00', '2024-09-07 09:00:00'),
(14, '2024-09-07 08:30:00', '2024-09-07 09:30:00'),
(15, '2024-09-08 10:00:00', '2024-09-08 11:00:00');

select * from sesiones;

-- Tabla de Devoluciones
CREATE TABLE devoluciones (
    id_devolucion INT PRIMARY KEY AUTO_INCREMENT,
    id_usuario INT,
    id_producto INT,
    fecha_devolucion DATE,
    estado_devolucion ENUM('pendiente', 'aprobada', 'rechazada'),
    cantidad INT,
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario),
    FOREIGN KEY (id_producto) REFERENCES productos(id_producto)
);

INSERT INTO devoluciones (id_usuario, id_producto, fecha_devolucion, estado_devolucion, cantidad)
VALUES
(1, 1, '2024-09-01', 'pendiente', 2),
(2, 2, '2024-09-02', 'aprobada', 1),
(3, 3, '2024-09-03', 'rechazada', 1),
(4, 1, '2024-09-04', 'aprobada', 3),
(5, 2, '2024-09-05', 'pendiente', 2),
(6, 3, '2024-09-06', 'aprobada', 1),
(7, 1, '2024-09-07', 'rechazada', 1),
(8, 2, '2024-09-08', 'pendiente', 2),
(9, 3, '2024-09-09', 'aprobada', 2),
(10, 1, '2024-09-10', 'pendiente', 3),
(11, 2, '2024-09-11', 'rechazada', 1),
(12, 3, '2024-09-12', 'aprobada', 2),
(13, 1, '2024-09-13', 'pendiente', 1),
(14, 2, '2024-09-14', 'aprobada', 2),
(15, 3, '2024-09-15', 'rechazada', 1);

-- Tabla de Productos (uniformes)
CREATE TABLE productos (
    id_producto INT PRIMARY KEY AUTO_INCREMENT,
    nombre_producto VARCHAR(100),
    tipo_producto ENUM('camisa', 'zapato', 'cinturon', 'jardinera'),
    talla VARCHAR(10),
    stock INT
);


-- Insertar productos
INSERT INTO productos (nombre_producto, tipo_producto, talla, stock)
VALUES
('Camisa Escolar', 'camisa', 'M', 50),
('Zapato Escolar', 'zapato', '42', 30),
('Cinturon Escolar', 'cinturon', 'L', 20),
('Jardinera Escolar', 'jardinera', 'S', 20);

---------------------------------------------------------------------------------------------------------------------------------------------

-- consultas inner join, left join y right join

-- inner join

# Obtener los usuarios que han hecho devoluciones:

SELECT u.nombre, d.fecha_devolucion, d.estado_devolucion
FROM usuarios u
INNER JOIN devoluciones d ON u.id = d.id_usuario;

# Obtener la fecha de inicio de sesión de los usuarios:

SELECT u.nombre, s.fecha_inicio
FROM usuarios u
INNER JOIN sesiones s ON u.id = s.id_usuario;

# Obtener los administradores que han hecho devoluciones:

SELECT u.nombre, d.fecha_devolucion
FROM usuarios u
INNER JOIN devoluciones d ON u.id = d.id_usuario
WHERE u.rol = 'administrador';

# Listar las devoluciones de usuarios específicos:

SELECT u.nombre, d.fecha_devolucion
FROM usuarios u
INNER JOIN devoluciones d ON u.id = d.id_usuario
WHERE u.nombre = 'Usuario 1';

# Obtener usuarios y sus sesiones con duración mayor a una hora:

SELECT u.nombre, s.fecha_inicio, TIMESTAMPDIFF(MINUTE, s.fecha_inicio, s.fecha_fin) AS duracion
FROM usuarios u
INNER JOIN sesiones s ON u.id = s.id_usuario
WHERE TIMESTAMPDIFF(MINUTE, s.fecha_inicio, s.fecha_fin) > 60;

# Obtener devoluciones aprobadas de usuarios:

SELECT u.nombre, d.fecha_devolucion
FROM usuarios u
INNER JOIN devoluciones d ON u.id = d.id_usuario
WHERE d.estado_devolucion = 'aprobada';

# Obtener usuarios que devolvieron más de 2 productos:

SELECT u.nombre, d.cantidad
FROM usuarios u
INNER JOIN devoluciones d ON u.id = d.id_usuario
WHERE d.cantidad > 2;

# Obtener usuarios y productos devueltos:

SELECT u.nombre, d.id_producto
FROM usuarios u
INNER JOIN devoluciones d ON u.id = d.id_usuario;

# Obtener usuarios y su última sesión:

SELECT u.nombre, MAX(s.fecha_inicio)
FROM usuarios u
INNER JOIN sesiones s ON u.id = s.id_usuario
GROUP BY u.nombre;

# Listar usuarios que realizaron sesiones en septiembre:

SELECT u.nombre, s.fecha_inicio
FROM usuarios u
INNER JOIN sesiones s ON u.id = s.id_usuario
WHERE s.fecha_inicio LIKE '2024-09%';

# Listar devoluciones rechazadas y los usuarios que las realizaron:


SELECT u.nombre, d.fecha_devolucion, d.estado_devolucion
FROM usuarios u
INNER JOIN devoluciones d ON u.id = d.id_usuario
WHERE d.estado_devolucion = 'rechazada';

# Mostrar usuarios que hicieron más de una devolución:

SELECT u.nombre, COUNT(d.id_devolucion) AS total_devoluciones
FROM usuarios u
INNER JOIN devoluciones d ON u.id = d.id_usuario
GROUP BY u.nombre
HAVING total_devoluciones > 1;

# Mostrar usuarios y productos devueltos por más de 1 unidad:

SELECT u.nombre, d.id_producto, d.cantidad
FROM usuarios u
INNER JOIN devoluciones d ON u.id = d.id_usuario
WHERE d.cantidad > 1;

# Obtener sesiones de usuarios que duraron más de 30 minutos:


SELECT u.nombre, s.fecha_inicio, TIMESTAMPDIFF(MINUTE, s.fecha_inicio, s.fecha_fin) AS duracion
FROM usuarios u
INNER JOIN sesiones s ON u.id = s.id_usuario
WHERE TIMESTAMPDIFF(MINUTE, s.fecha_inicio, s.fecha_fin) > 30;

# Listar los usuarios que tienen sesiones pero no devoluciones:


SELECT u.nombre, s.fecha_inicio
FROM usuarios u
INNER JOIN sesiones s ON u.id = s.id_usuario
LEFT JOIN devoluciones d ON u.id = d.id_usuario
WHERE d.id_devolucion IS NULL;

-----------------------------------------------------------------------------------------------------------------------------------------------------------

-- LEFT JOIN
-- Estas consultas devolverán todos los registros de la tabla de la izquierda (usuarios), incluso si no hay coincidencia en la tabla derecha (devoluciones o sesiones).

# Obtener todos los usuarios y sus devoluciones (si existen):

SELECT u.nombre, d.fecha_devolucion
FROM usuarios u
LEFT JOIN devoluciones d ON u.id = d.id_usuario;

# Obtener todos los usuarios y sus sesiones (si existen):


SELECT u.nombre, s.fecha_inicio
FROM usuarios u
LEFT JOIN sesiones s ON u.id = s.id_usuario;

# Listar todos los usuarios y sus devoluciones aprobadas:


SELECT u.nombre, d.estado_devolucion
FROM usuarios u
LEFT JOIN devoluciones d ON u.id = d.id_usuario
WHERE d.estado_devolucion = 'aprobada';

# Listar usuarios sin devoluciones:


SELECT u.nombre
FROM usuarios u
LEFT JOIN devoluciones d ON u.id = d.id_usuario
WHERE d.id_devolucion IS NULL;

# Listar usuarios con devoluciones pendientes o sin devoluciones:


SELECT u.nombre, d.estado_devolucion
FROM usuarios u
LEFT JOIN devoluciones d ON u.id = d.id_usuario
WHERE d.estado_devolucion = 'pendiente' OR d.estado_devolucion IS NULL;

# Listar todos los usuarios y cantidad devuelta, si aplica:


SELECT u.nombre, d.cantidad
FROM usuarios u
LEFT JOIN devoluciones d ON u.id = d.id_usuario;

# Listar todos los usuarios y su última sesión (si existe):


SELECT u.nombre, MAX(s.fecha_inicio)
FROM usuarios u
LEFT JOIN sesiones s ON u.id = s.id_usuario
GROUP BY u.nombre;

# Mostrar devoluciones rechazadas o usuarios sin devoluciones:


SELECT u.nombre, d.estado_devolucion
FROM usuarios u
LEFT JOIN devoluciones d ON u.id = d.id_usuario
WHERE d.estado_devolucion = 'rechazada' OR d.estado_devolucion IS NULL;

# Obtener usuarios que han iniciado sesión pero no devolvieron:


SELECT u.nombre, s.fecha_inicio
FROM usuarios u
LEFT JOIN sesiones s ON u.id = s.id_usuario
LEFT JOIN devoluciones d ON u.id = d.id_usuario
WHERE d.id_devolucion IS NULL;

# Listar todos los administradores y su actividad de devolución:


SELECT u.nombre, d.fecha_devolucion
FROM usuarios u
LEFT JOIN devoluciones d ON u.id = d.id_usuario
WHERE u.rol = 'administrador';

# Listar todos los usuarios y sus devoluciones aprobadas o sin devolución:


SELECT u.nombre, d.estado_devolucion
FROM usuarios u
LEFT JOIN devoluciones d ON u.id = d.id_usuario
WHERE d.estado_devolucion = 'aprobada' OR d.estado_devolucion IS NULL;

# Mostrar los usuarios con devoluciones de menos de 2 productos:


SELECT u.nombre, d.cantidad
FROM usuarios u
LEFT JOIN devoluciones d ON u.id = d.id_usuario
WHERE d.cantidad < 2 OR d.cantidad IS NULL;

# Mostrar todos los usuarios con sesiones largas:


SELECT u.nombre, TIMESTAMPDIFF(MINUTE, s.fecha_inicio, s.fecha_fin) AS duracion
FROM usuarios u
LEFT JOIN sesiones s ON u.id = s.id_usuario
WHERE TIMESTAMPDIFF(MINUTE, s.fecha_inicio, s.fecha_fin) > 60 OR s.fecha_inicio IS NULL;

# Listar usuarios y productos devueltos si existen devoluciones:


SELECT u.nombre, d.id_producto
FROM usuarios u
LEFT JOIN devoluciones d ON u.id = d.id_usuario;

# Mostrar todos los usuarios y la cantidad de devoluciones, si existen:


SELECT u.nombre, COUNT(d.id_devolucion) AS total_devoluciones
FROM usuarios u
LEFT JOIN devoluciones d ON u.id = d.id_usuario
GROUP BY u.nombre;

-----------------------------------------------------------------------------------------------------------------------------------------------

-- RIGHT JOIN

# Obtener todas las devoluciones y los usuarios que las realizaron (si existen):


SELECT u.nombre, d.fecha_devolucion
FROM usuarios u
RIGHT JOIN devoluciones d ON u.id = d.id_usuario;

# Obtener todas las sesiones y los usuarios (si existen):


SELECT u.nombre, s.fecha_inicio
FROM usuarios u
RIGHT JOIN sesiones s ON u.id = s.id_usuario;

# Listar todas las devoluciones aprobadas y los usuarios que las realizaron:


SELECT u.nombre, d.estado_devolucion
FROM usuarios u
RIGHT JOIN devoluciones d ON u.id = d.id_usuario
WHERE d.estado_devolucion = 'aprobada';

# Mostrar todas las devoluciones y los usuarios que las hicieron o devolver NULL si el usuario no existe:


SELECT u.nombre, d.fecha_devolucion
FROM usuarios u
RIGHT JOIN devoluciones d ON u.id = d.id_usuario;

# Obtener devoluciones rechazadas y los usuarios que las hicieron:


SELECT u.nombre, d.estado_devolucion
FROM usuarios u
RIGHT JOIN devoluciones d ON u.id = d.id_usuario
WHERE d.estado_devolucion = 'rechazada';

# Obtener todas las sesiones y los usuarios que iniciaron sesión:


SELECT u.nombre, s.fecha_inicio
FROM usuarios u
RIGHT JOIN sesiones s ON u.id = s.id_usuario;

# Listar todas las devoluciones y usuarios con estado 'pendiente':


SELECT u.nombre, d.estado_devolucion
FROM usuarios u
RIGHT JOIN devoluciones d ON u.id = d.id_usuario
WHERE d.estado_devolucion = 'pendiente';

# Mostrar devoluciones con cantidad superior a 2, con los usuarios que las realizaron:


SELECT u.nombre, d.cantidad
FROM usuarios u
RIGHT JOIN devoluciones d ON u.id = d.id_usuario
WHERE d.cantidad > 2;

# Mostrar todas las sesiones y sus usuarios asociados o NULL si no existe usuario:


SELECT u.nombre, s.fecha_inicio
FROM usuarios u
RIGHT JOIN sesiones s ON u.id = s.id_usuario;

# Listar devoluciones por producto y sus usuarios asociados:


SELECT u.nombre, d.id_producto
FROM usuarios u
RIGHT JOIN devoluciones d ON u.id = d.id_usuario;

# Mostrar devoluciones en un rango de fechas y sus usuarios asociados:


SELECT u.nombre, d.fecha_devolucion
FROM usuarios u
RIGHT JOIN devoluciones d ON u.id = d.id_usuario
WHERE d.fecha_devolucion BETWEEN '2024-09-01' AND '2024-09-10';

# Mostrar sesiones largas (más de 60 minutos) y los usuarios que las iniciaron:


SELECT u.nombre, s.fecha_inicio, TIMESTAMPDIFF(MINUTE, s.fecha_inicio, s.fecha_fin) AS duracion
FROM usuarios u
RIGHT JOIN sesiones s ON u.id = s.id_usuario
WHERE TIMESTAMPDIFF(MINUTE, s.fecha_inicio, s.fecha_fin) > 60;

# Listar todas las devoluciones y los productos devueltos, mostrando también el nombre del usuario si existe:


SELECT u.nombre, d.id_producto, d.fecha_devolucion
FROM usuarios u
RIGHT JOIN devoluciones d ON u.id = d.id_usuario;

# Mostrar todas las devoluciones pendientes y sus usuarios, si existen:


SELECT u.nombre, d.fecha_devolucion, d.estado_devolucion
FROM usuarios u
RIGHT JOIN devoluciones d ON u.id = d.id_usuario
WHERE d.estado_devolucion = 'pendiente';

# Listar todas las sesiones y sus duraciones, con los usuarios que iniciaron la sesión o NULL si no existe usuario:


SELECT u.nombre, s.fecha_inicio, TIMESTAMPDIFF(MINUTE, s.fecha_inicio, s.fecha_fin) AS duracion
FROM usuarios u
RIGHT JOIN sesiones s ON u.id = s.id_usuario;

------------------------------------------------------------------------------------------------------

-- Consultas anidadas:

# Devoluciones pendientes de un usuario específico:

SELECT * FROM devoluciones WHERE id_usuario = 
(SELECT id_usuario FROM usuarios WHERE email = 'usuario1@ejemplo.com') AND estado_devolucion = 'pendiente';


# Obtener productos devueltos por usuarios administradores:

SELECT p.nombre_producto, d.fecha_devolucion 
FROM devoluciones d 
JOIN productos p ON d.id_producto = p.id_producto 
WHERE d.id_usuario IN 
(SELECT id_usuario FROM usuarios WHERE rol = 'administrador');


# Obtener usuarios con más de 5 devoluciones:

SELECT nombre FROM usuarios WHERE id_usuario IN 
(SELECT id_usuario FROM devoluciones GROUP BY id_usuario HAVING COUNT(*) > 5);


# Usuarios que hayan devuelto camisas:

SELECT nombre FROM usuarios WHERE id_usuario IN 
(SELECT id_usuario FROM devoluciones WHERE id_producto IN 
(SELECT id_producto FROM productos WHERE tipo_producto = 'camisa'));


# Productos más devueltos:

SELECT nombre_producto FROM productos WHERE id_producto IN 
(SELECT id_producto FROM devoluciones GROUP BY id_producto ORDER BY COUNT(*) DESC LIMIT 1);

# Devoluciones aprobadas en los últimos 7 días:

SELECT * FROM devoluciones WHERE estado_devolucion = 'aprobada' 
AND fecha_devolucion > NOW() - INTERVAL 7 DAY;

# Cantidad total devuelta de cada producto:

SELECT nombre_producto, (SELECT SUM(cantidad) FROM devoluciones d WHERE d.id_producto = p.id_producto) AS total_devuelto 
FROM productos p;

# Historial de sesiones de un usuario específico:

SELECT * FROM sesiones WHERE id_usuario = 
(SELECT id_usuario FROM usuarios WHERE email = 'usuario1@ejemplo.com');

# Usuarios que no han hecho devoluciones:

SELECT nombre FROM usuarios WHERE id_usuario NOT IN 
(SELECT id_usuario FROM devoluciones);


# Stock actual de un producto tras las devoluciones:

SELECT nombre_producto, (stock - (SELECT SUM(cantidad) FROM devoluciones WHERE id_producto = p.id_producto)) AS stock_actual 
FROM productos p WHERE nombre_producto = 'Camisa Escolar';


# Usuarios que devolvieron más de 3 productos en una sola devolución:

SELECT nombre FROM usuarios WHERE id_usuario IN 
(SELECT id_usuario FROM devoluciones WHERE cantidad > 3);


# Última sesión de cada usuario:

SELECT nombre, (SELECT MAX(fecha_inicio) FROM sesiones WHERE id_usuario = u.id_usuario) AS ultima_sesion 
FROM usuarios u;


# Administradores que han realizado devoluciones:

SELECT nombre FROM usuarios WHERE rol = 'administrador' AND id_usuario IN 
(SELECT id_usuario FROM devoluciones);


# Devoluciones de productos con más de 10 unidades:

SELECT * FROM devoluciones WHERE cantidad > 10;


# Historial de devoluciones de un producto específico:

SELECT * FROM devoluciones WHERE id_producto = 
(SELECT id_producto FROM productos WHERE nombre_producto = 'Cinturon Escolar');

