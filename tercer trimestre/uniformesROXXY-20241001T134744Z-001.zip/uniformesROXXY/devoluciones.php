<?php
include 'conexion.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_SESSION['usuario_id'])) {
    $usuario_id = $_SESSION['usuario_id'];
    $uniforme = $_POST['uniforme'];
    $cantidad = $_POST['cantidad'];

    $sql = "INSERT INTO devoluciones (usuario_id, uniforme, cantidad) VALUES ('$usuario_id', '$uniforme', '$cantidad')";

    if ($conn->query($sql) === TRUE) {
        echo "Devolución registrada exitosamente.";
        header('Location: lista_devoluciones.php');  // Redirigir a la lista de devoluciones
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
