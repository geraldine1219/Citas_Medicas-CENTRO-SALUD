CREATE DATABASE sistema_devoluciones;

USE sistema_devoluciones;

CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL
);

CREATE TABLE devoluciones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT,
    uniforme VARCHAR(50),
    cantidad INT,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

ALTER TABLE usuarios ADD COLUMN rol ENUM('usuario', 'administrador') DEFAULT 'usuario';
