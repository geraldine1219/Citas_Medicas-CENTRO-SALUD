<?php
include 'conexion.php';
session_start();

if (isset($_GET['id']) && isset($_SESSION['usuario_id'])) {
    $id = $_GET['id'];

    $sql = "DELETE FROM devoluciones WHERE id='$id'";

    if ($conn->query($sql) === TRUE) {
        echo "Devolución eliminada.";
        header('Location: lista_devoluciones.php');  // Redirigir a la lista de devoluciones
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
