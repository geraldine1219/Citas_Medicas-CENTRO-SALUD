<?php
include 'conexion.php';
session_start();

if (isset($_SESSION['usuario_id'])) {
    $usuario_id = $_SESSION['usuario_id'];

    $sql = "SELECT * FROM devoluciones WHERE usuario_id='$usuario_id'";
    $result = $conn->query($sql);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Devoluciones</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Tus Devoluciones</h1>
    </header>
    <section>
        <table>
            <tr>
                <th>ID</th>
                <th>Uniforme</th>
                <th>Cantidad</th>
                <th>Fecha</th>
                <th>Acciones</th>
            </tr>
            <?php while($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['uniforme']; ?></td>
                <td><?php echo $row['cantidad']; ?></td>
                <td><?php echo $row['fecha']; ?></td>
                <td>
                    <a href="editar_devolucion.php?id=<?php echo $row['id']; ?>">Editar</a>
                    <a href="eliminar_devolucion.php?id=<?php echo $row['id']; ?>">Eliminar</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    </section>
</body>
</html>
