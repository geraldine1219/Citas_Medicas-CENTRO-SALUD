<?php
include 'conexion.php';
session_start();

if (isset($_GET['id']) && isset($_SESSION['usuario_id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM devoluciones WHERE id='$id'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $devolucion = $result->fetch_assoc();
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $uniforme = $_POST['uniforme'];
    $cantidad = $_POST['cantidad'];

    $sql = "UPDATE devoluciones SET uniforme='$uniforme', cantidad='$cantidad' WHERE id='$id'";

    if ($conn->query($sql) === TRUE) {
        echo "Devolución actualizada.";
        header('Location: lista_devoluciones.php');  // Redirigir a la lista de devoluciones
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Devolución</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Editar Devolución</h1>
    </header>
    <section>
        <form action="" method="POST">
            <label for="uniforme">Uniforme:</label>
            <input type="text" id="uniforme" name="uniforme" value="<?php echo $devolucion['uniforme']; ?>" required>

            <label for="cantidad">Cantidad:</label>
            <input type="number" id="cantidad" name="cantidad" value="<?php echo $devolucion['cantidad']; ?>" required>

            <button type="submit">Actualizar</button>
        </form>
    </section>
</body>
</html>
