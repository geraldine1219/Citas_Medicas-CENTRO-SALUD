<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrito de Devoluciones</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Carrito de Devoluciones</h1>
        <nav>
            <ul>
                <li><a href="index.html">Inicio</a></li>
                <li><a href="carrito_devoluciones.php">Carrito de Devoluciones</a></li>
                <li><a href="logout.php">Cerrar Sesión</a></li>
            </ul>
        </nav>
    </header>
    <section>
        <h2>Devolver Uniformes</h2>
        <form action="devolucion.php" method="POST">
            <label for="uniforme">Seleccionar Uniforme:</label>
            <select id="uniforme" name="uniforme">
                <option value="camisa">Camisa</option>
                <option value="pantalon">Pantalón</option>
                <option value="falda">Falda</option>
            </select>

            <label for="cantidad">Cantidad:</label>
            <input type="number" id="cantidad" name="cantidad" min="1" required>

            <button type="submit">Devolver</button>
        </form>
    </section>
</body>
</html>
